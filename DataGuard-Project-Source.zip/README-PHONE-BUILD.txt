Data Guard - build from a phone using GitHub Actions

IMPORTANT: This is an Android Studio project source ZIP, not an APK.

The workflow in .github/workflows/build-apk.yml is designed to:
1. Find a ZIP in the root of your GitHub repository.
2. Extract it.
3. Install Gradle 8.11.1 and use Java 17 (the project does not include gradlew).
4. Build app/build/outputs/apk/debug/*.apk.
5. Publish DataGuard-debug.apk under Actions > latest run > Artifacts.

Phone steps:
- Upload this ZIP to the ROOT of your GitHub repository.
- Also create/replace the repository file .github/workflows/build-apk.yml using the same path from this ZIP, OR upload the workflow file separately at that path.
- In Actions, choose Build Data Guard APK > Run workflow.
- If the build succeeds, download the DataGuard-APK artifact and extract the APK from the downloaded artifact ZIP.

The APK is a debug build. It has not been installed or field-tested on a physical phone. Verify permissions, Wi-Fi/mobile counters, background operation and battery behavior before relying on it for billing or package-limit decisions.
