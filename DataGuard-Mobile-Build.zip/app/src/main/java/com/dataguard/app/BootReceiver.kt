package com.dataguard.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = context.getSharedPreferences(MonitorService.PREFS, Context.MODE_PRIVATE)
            if (prefs.getBoolean("monitor_enabled", false)) {
                ContextCompat.startForegroundService(context, Intent(context, MonitorService::class.java))
            }
        }
    }
}
