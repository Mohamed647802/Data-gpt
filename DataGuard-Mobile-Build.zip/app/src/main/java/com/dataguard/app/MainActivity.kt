package com.dataguard.app

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(MonitorService.PREFS, MODE_PRIVATE) }
    private lateinit var limit: EditText
    private lateinit var unit: Spinner
    private lateinit var network: Spinner
    private lateinit var period: Spinner
    private lateinit var warn: EditText
    private lateinit var startDate: Button
    private lateinit var endDate: Button
    private var startIso = prefs.getString("start_date", "") ?: ""
    private var endIso = prefs.getString("end_date", "") ?: ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(244,247,251)
        window.navigationBarColor = android.graphics.Color.rgb(244,247,251)
        if (Build.VERSION.SDK_INT >= 23) window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 71)
        }
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(28))
            setBackgroundColor(0xFFF4F7FB.toInt())
            layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply { text = "Data Guard"; textSize = 29f; setTextColor(0xFF14243A.toInt()); gravity = Gravity.RIGHT; setTypeface(null, android.graphics.Typeface.BOLD) })
        root.addView(TextView(this).apply { text = "راقب استهلاك الإنترنت من الجهاز نفسه"; textSize = 15f; setTextColor(0xFF607086.toInt()); setPadding(0, dp(5), 0, dp(22)) })

        section(root, "حد الاستهلاك")
        limit = EditText(this).apply { hint = "مثال: 10"; inputType =  android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; textSize = 18f; setSingleLine(true); setText(prefs.getString("limit", "10")) }
        root.addView(limit, lp())
        unit = spinner(root, listOf("GB", "MB"), prefs.getInt("unit", 0))

        section(root, "الشبكة التي تريد مراقبتها")
        network = spinner(root, listOf("الاثنان معًا", "Wi-Fi فقط", "بيانات الهاتف فقط"), prefs.getInt("network", 0))

        section(root, "فترة الحساب")
        period = spinner(root, listOf("يومي – يبدأ منتصف الليل", "شهري – يبدأ يوم 1", "فترة مخصصة"), prefs.getInt("period", 0))
        startDate = Button(this).apply { text = "بداية الفترة: ${startIso.ifBlank { "اختر التاريخ" }}"; setOnClickListener { pickDate(true) } }
        endDate = Button(this).apply { text = "نهاية الفترة: ${endIso.ifBlank { "اختر التاريخ" }}"; setOnClickListener { pickDate(false) } }
        root.addView(startDate, lp())
        root.addView(endDate, lp())
        period.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                startDate.visibility = if (position == 2) android.view.View.VISIBLE else android.view.View.GONE
                endDate.visibility = if (position == 2) android.view.View.VISIBLE else android.view.View.GONE
            }
        }

        section(root, "تنبيه الاقتراب من الحد")
        warn = EditText(this).apply { hint = "80"; inputType = android.text.InputType.TYPE_CLASS_NUMBER; textSize = 18f; setSingleLine(true); setText(prefs.getInt("warning", 80).toString()) }
        root.addView(warn, lp())
        root.addView(TextView(this).apply { text = "النسبة الافتراضية 80%، ثم تنبيه آخر عند بلوغ 100%."; textSize = 13f; setTextColor(0xFF607086.toInt()); setPadding(0, dp(4), 0, dp(16)) })

        val save = Button(this).apply {
            text = "حفظ وتشغيل المراقبة"
            textSize = 17f
            setTextColor(-1)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF1769E0.toInt()))
            setOnClickListener { saveAndStart() }
        }
        root.addView(save, lp())
        root.addView(TextView(this).apply {
            text = "ملاحظة الدقة: القراءة من عدادات Android على مستوى الجهاز. اترك خدمة المراقبة مفعّلة طوال الفترة؛ لا يستطيع التطبيق استرجاع استهلاك سابق قبل تشغيله. وقد تختلف القراءة قليلًا عن محاسبة شركة الاتصالات بسبب طريقة احتساب الشبكة."
            textSize = 12f; setTextColor(0xFF65758B.toInt()); setPadding(0, dp(18), 0, 0)
        })
    }

    private fun section(root: LinearLayout, title: String) {
        root.addView(TextView(this).apply { text = title; textSize = 16f; setTextColor(0xFF23364D.toInt()); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, dp(14), 0, dp(7)) })
    }

    private fun spinner(root: LinearLayout, values: List<String>, selected: Int): Spinner {
        val s = Spinner(this)
        s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, values)
        s.setSelection(selected.coerceIn(values.indices))
        root.addView(s, lp())
        return s
    }

    private fun lp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { bottomMargin = dp(8) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun pickDate(isStart: Boolean) {
        val c = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            val iso = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)
            if (isStart) { startIso = iso; startDate.text = "بداية الفترة: $iso" }
            else { endIso = iso; endDate.text = "نهاية الفترة: $iso" }
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun saveAndStart() {
        val amount = limit.text.toString().toDoubleOrNull()
        val threshold = warn.text.toString().toIntOrNull()
        if (amount == null || amount <= 0 || threshold == null || threshold !in 1..99) {
            Toast.makeText(this, "أدخل حدًا أكبر من صفر ونسبة تنبيه من 1 إلى 99", Toast.LENGTH_LONG).show(); return
        }
        if (period.selectedItemPosition == 2 && (startIso.isBlank() || endIso.isBlank() || endIso < startIso)) {
            Toast.makeText(this, "اختر تاريخ بداية ونهاية صحيحين", Toast.LENGTH_LONG).show(); return
        }
        val oldPeriod = prefs.getInt("period", 0)
        val oldStart = prefs.getString("start_date", "") ?: ""
        val oldEnd = prefs.getString("end_date", "") ?: ""
        prefs.edit()
            .putString("limit", amount.toString()).putInt("unit", unit.selectedItemPosition)
            .putInt("network", network.selectedItemPosition).putInt("period", period.selectedItemPosition)
            .putInt("warning", threshold).putString("start_date", startIso).putString("end_date", endIso)
            .apply()
        if (oldPeriod != period.selectedItemPosition || oldStart != startIso || oldEnd != endIso) {
            prefs.edit().putBoolean("initialized", false).putString("active_period_key", "").apply()
        }
        prefs.edit().putBoolean("warning_sent", false).putBoolean("limit_sent", false).putBoolean("monitor_enabled", true).apply()
        val intent = Intent(this, MonitorService::class.java)
        ContextCompat.startForegroundService(this, intent)
        Toast.makeText(this, "تم حفظ الإعدادات وتشغيل المراقبة", Toast.LENGTH_SHORT).show()
    }
}
