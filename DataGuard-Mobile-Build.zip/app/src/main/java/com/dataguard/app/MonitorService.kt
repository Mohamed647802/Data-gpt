package com.dataguard.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.TrafficStats
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MonitorService : Service() {
    companion object {
        const val PREFS = "data_guard_settings"
        private const val CHANNEL = "data_guard_monitor"
        private const val ALERT_CHANNEL = "data_guard_alerts"
        private const val NOTIFICATION_ID = 4107
        private const val POLL_MS = 60_000L
    }
    private val prefs by lazy { getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val fmt = DecimalFormat("0.00")

    private val poll = object : Runnable {
        override fun run() {
            try { updateCountersAndNotify() } catch (_: Exception) { }
            handler.postDelayed(this, POLL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForegroundCompat()
        handler.post(poll)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundCompat()
        return START_STICKY
    }

    override fun onDestroy() { handler.removeCallbacks(poll); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundCompat() {
        val n = buildNotification("جارٍ بدء قياس الاستهلاك…", "سيتم تحديث القراءة كل دقيقة")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(NOTIFICATION_ID, n)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "مراقبة استهلاك الإنترنت", NotificationManager.IMPORTANCE_LOW).apply {
                description = "إشعار دائم يعرض استهلاك الإنترنت والحد المتبقي"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
            val alerts = NotificationChannel(ALERT_CHANNEL, "تنبيهات حد الاستهلاك", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "تنبيه عند الاقتراب من حد البيانات أو بلوغه"
                enableVibration(true)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(alerts)
        }
    }

    private fun updateCountersAndNotify() {
        val totalRx = TrafficStats.getTotalRxBytes()
        val totalTx = TrafficStats.getTotalTxBytes()
        val mobileRx = TrafficStats.getMobileRxBytes()
        val mobileTx = TrafficStats.getMobileTxBytes()
        if (totalRx == TrafficStats.UNSUPPORTED || totalTx == TrafficStats.UNSUPPORTED ||
            mobileRx == TrafficStats.UNSUPPORTED || mobileTx == TrafficStats.UNSUPPORTED) {
            updateNotification("تعذر قراءة عدادات الشبكة", "هذا الجهاز لا يتيح عدادات TrafficStats المطلوبة.")
            return
        }
        val total = totalRx + totalTx
        val mobile = mobileRx + mobileTx
        val wifi = (total - mobile).coerceAtLeast(0L)
        val now = System.currentTimeMillis()
        val period = prefs.getInt("period", 0)
        val key = when (period) {
            0 -> SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date(now))
            1 -> SimpleDateFormat("yyyyMM", Locale.getDefault()).format(Date(now))
            else -> prefs.getString("start_date", "") ?: ""
        }
        if (prefs.getString("active_period_key", "") != key) {
            prefs.edit().putString("active_period_key", key).putBoolean("initialized", false)
                .putLong("used_wifi", 0L).putLong("used_mobile", 0L)
                .putBoolean("warning_sent", false).putBoolean("limit_sent", false).apply()
        }
        if (period == 2) {
            val start = parseDate(prefs.getString("start_date", "") ?: "")
            val end = parseDate(prefs.getString("end_date", "") ?: "") + 86_399_999L
            if (start <= 0 || now < start || now > end) {
                updateNotification("خارج الفترة المحددة", "لن يتم احتساب الاستخدام خارج تاريخ البداية والنهاية")
                return
            }
        }

        val initialized = prefs.getBoolean("initialized", false)
        var usedWifi = prefs.getLong("used_wifi", 0L)
        var usedMobile = prefs.getLong("used_mobile", 0L)
        val lastWifi = prefs.getLong("last_wifi", -1L)
        val lastMobile = prefs.getLong("last_mobile", -1L)
        if (!initialized || lastWifi < 0 || lastMobile < 0) {
            usedWifi = 0L; usedMobile = 0L
        } else {
            usedWifi += if (wifi >= lastWifi) wifi - lastWifi else wifi
            usedMobile += if (mobile >= lastMobile) mobile - lastMobile else mobile
        }
        prefs.edit().putBoolean("initialized", true).putLong("used_wifi", usedWifi)
            .putLong("used_mobile", usedMobile).putLong("last_wifi", wifi).putLong("last_mobile", mobile).apply()

        val selected = when (prefs.getInt("network", 0)) {
            1 -> usedWifi
            2 -> usedMobile
            else -> usedWifi + usedMobile
        }
        val amount = (prefs.getString("limit", "10") ?: "10").toDoubleOrNull() ?: 10.0
        val multiplier = if (prefs.getInt("unit", 0) == 1) 1024.0 * 1024.0 else 1024.0 * 1024.0 * 1024.0
        val limitBytes = (amount * multiplier).toLong().coerceAtLeast(1L)
        val ratio = selected.toDouble() / limitBytes.toDouble()
        val warning = prefs.getInt("warning", 80) / 100.0
        val warningSent = prefs.getBoolean("warning_sent", false)
        val limitSent = prefs.getBoolean("limit_sent", false)
        if (ratio >= warning && !warningSent) {
            sendAlert("اقتربت من حد الاستهلاك", "استهلكت ${fmt.format(ratio * 100)}% من الحد المحدد.")
            prefs.edit().putBoolean("warning_sent", true).apply()
        }
        if (ratio >= 1.0 && !limitSent) {
            sendAlert("وصلت إلى حد الاستهلاك", "تجاوزت الحد الذي حددته في Data Guard.")
            prefs.edit().putBoolean("limit_sent", true).apply()
        }
        if (ratio < warning) prefs.edit().putBoolean("warning_sent", false).apply()
        if (ratio < 1.0) prefs.edit().putBoolean("limit_sent", false).apply()

        val usedText = formatBytes(selected)
        val leftText = formatBytes((limitBytes - selected).coerceAtLeast(0L))
        val pct = fmt.format(ratio * 100)
        val networkName = when (prefs.getInt("network", 0)) { 1 -> "Wi-Fi"; 2 -> "بيانات الهاتف"; else -> "Wi-Fi + بيانات الهاتف" }
        updateNotification("$usedText من ${formatBytes(limitBytes)} ($pct%)", "المتبقي $leftText • $networkName")
    }

    private fun parseDate(s: String): Long = try { SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(s)?.time ?: -1L } catch (_: Exception) { -1L }
    private fun formatBytes(bytes: Long): String {
        val gb = bytes / (1024.0 * 1024.0 * 1024.0)
        return if (gb >= 1.0) "${fmt.format(gb)} GB" else "${fmt.format(bytes / (1024.0 * 1024.0))} MB"
    }
    private fun buildNotification(title: String, body: String): android.app.Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
            .setContentTitle(title).setContentText(body).setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE).setPriority(NotificationCompat.PRIORITY_LOW).build()
    }
    private fun updateNotification(title: String, body: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(title, body))
    }
    private fun sendAlert(title: String, body: String) {
        val n = NotificationCompat.Builder(this, ALERT_CHANNEL).setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle(title).setContentText(body).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
    }
}
